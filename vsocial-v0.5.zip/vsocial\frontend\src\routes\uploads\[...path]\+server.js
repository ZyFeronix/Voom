import { getRootDir } from '$lib/server/db.js';
import { readFileSync, existsSync, statSync } from 'fs';
import { resolve } from 'path';

export async function GET({ params }) {
	const rootDir = getRootDir();
	// Prevent directory traversal attacks
	const safePath = params.path.replace(/\.\./g, '');
	const fullPath = resolve(rootDir, 'uploads', safePath);

	if (!existsSync(fullPath)) {
		return new Response('Not found', { status: 404 });
	}

	const stat = statSync(fullPath);
	if (stat.isDirectory()) {
		return new Response('Forbidden', { status: 403 });
	}

	try {
		const fileBuffer = readFileSync(fullPath);

		const ext = fullPath.split('.').pop().toLowerCase();
		const mimeTypes = {
			jpg: 'image/jpeg',
			jpeg: 'image/jpeg',
			png: 'image/png',
			gif: 'image/gif',
			webp: 'image/webp',
			svg: 'image/svg+xml',
			mp4: 'video/mp4',
			webm: 'video/webm',
			mp3: 'audio/mpeg',
			wav: 'audio/wav',
			ogg: 'audio/ogg'
		};
		const contentType = mimeTypes[ext] || 'application/octet-stream';

		return new Response(fileBuffer, {
			headers: {
				'Content-Type': contentType,
				'Cache-Control': 'public, max-age=31536000, immutable'
			}
		});
	} catch (_err) {
		return new Response('Error reading file', { status: 500 });
	}
}
